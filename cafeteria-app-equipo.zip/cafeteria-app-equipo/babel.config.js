module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    // Nota: desde Expo SDK 54, babel-preset-expo configura automáticamente
    // el plugin de Reanimated/Worklets. NO agregar 'react-native-worklets/plugin'
    // ni 'react-native-reanimated/plugin' a mano aquí, o dará error de
    // "Duplicate plugin/preset detected".
  };
};
